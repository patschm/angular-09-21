import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-product-review></app-product-review>`,
  styles: []
})
export class AppComponent {
  title = 'shop';
}
