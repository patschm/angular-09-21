const data = [{productID: 1, score: 5, author: 'Jan Keizer', text: 'This product is great!!!!'},
    {productID: 1, score: 3, author: 'Petra Conner', text: 'Product is meh!'}];

import { Review } from '../../entities/entities';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-review-list',
  templateUrl: './product-review-list.component.html',
  styleUrls: ['./product-review-list.component.css']
})
export class ProductReviewListComponent implements OnInit {

  public reviews: Review[] = data;
  public productID = 1;

  // TODO: 5
  // Create the onAdd function which accepts an argument of type Review
  // Push the review on the reviews list

  
  constructor() { }

  ngOnInit(): void {
  }

}
