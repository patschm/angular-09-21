import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-product-review-list></app-product-review-list>`,
  styles: []
})
export class AppComponent {
  title = 'shop';
}
