export interface AppConfig {
    apiEndpoint: string;
  }