import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';

import { AppComponent } from './app.component';
import { ElementComponent } from './element/element.component';

import { createCustomElement } from '@angular/elements';

@NgModule({
  declarations: [
    AppComponent,
    ElementComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  //bootstrap: [AppComponent]
  entryComponents:[ElementComponent]
})
export class AppModule { 
  constructor(private injector: Injector)
  {
  }
  ngDoBootstrap()
  {
    let el = createCustomElement(ElementComponent, { injector: this.injector});
    customElements.define("my-element", el);
  }
}
