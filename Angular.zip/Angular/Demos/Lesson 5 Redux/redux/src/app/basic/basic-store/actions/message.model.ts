export class Message
{
    index:number;
    text:string;
}