import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub2',
  template: `<h1>Sub 2</h1>`,
  styles: []
})
export class Sub2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
